package com.yourname.lcvillagertycoon.network;

import com.yourname.lcvillagertycoon.tycoon.TycoonStats;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class C2SToggleTycoonPacket {
    private final long traderId;
    private final boolean newState;

    public C2SToggleTycoonPacket(long traderId, boolean newState) {
        this.traderId = traderId;
        this.newState = newState;
    }

    public static void encode(C2SToggleTycoonPacket msg, FriendlyByteBuf buf) {
        buf.writeLong(msg.traderId);
        buf.writeBoolean(msg.newState);
    }

    public static C2SToggleTycoonPacket decode(FriendlyByteBuf buf) {
        return new C2SToggleTycoonPacket(buf.readLong(), buf.readBoolean());
    }

    public static void handle(C2SToggleTycoonPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sender = ctx.get().getSender();
            if (sender != null) {
                ServerLevel level = sender.serverLevel();
                TycoonStats.get(level).setTycoonEnabled(msg.traderId, msg.newState);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
