package com.yourname.lcvillagertycoon.network;

import com.yourname.lcvillagertycoon.LCVillagerTycoonMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class TycoonNetwork {

    private static final String PROTOCOL_VERSION = "2";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(LCVillagerTycoonMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    public static void register() {
        int id = 0;

        CHANNEL.registerMessage(id++, TycoonStatsPacket.class,
                TycoonStatsPacket::encode,
                TycoonStatsPacket::decode,
                TycoonStatsPacket::handle);

        CHANNEL.registerMessage(id++, TycoonReputationPacket.class,
                TycoonReputationPacket::encode,
                TycoonReputationPacket::decode,
                TycoonReputationPacket::handle);

        CHANNEL.registerMessage(id++, C2SToggleTycoonPacket.class,
                C2SToggleTycoonPacket::encode,
                C2SToggleTycoonPacket::decode,
                C2SToggleTycoonPacket::handle);

        CHANNEL.registerMessage(id++, S2CSyncTycoonStatusPacket.class,
                S2CSyncTycoonStatusPacket::encode,
                S2CSyncTycoonStatusPacket::decode,
                S2CSyncTycoonStatusPacket::handle);

        CHANNEL.registerMessage(id++, C2SRequestTycoonStatusPacket.class,
                C2SRequestTycoonStatusPacket::encode,
                C2SRequestTycoonStatusPacket::decode,
                C2SRequestTycoonStatusPacket::handle);
    }
}
