package com.yourname.lcvillagertycoon.network;

import com.yourname.lcvillagertycoon.tycoon.TycoonStats;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.function.Supplier;

public class C2SRequestTycoonStatusPacket {
    private final long traderId;

    public C2SRequestTycoonStatusPacket(long traderId) {
        this.traderId = traderId;
    }

    public static void encode(C2SRequestTycoonStatusPacket msg, FriendlyByteBuf buf) {
        buf.writeLong(msg.traderId);
    }

    public static C2SRequestTycoonStatusPacket decode(FriendlyByteBuf buf) {
        return new C2SRequestTycoonStatusPacket(buf.readLong());
    }

    public static void handle(C2SRequestTycoonStatusPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sender = ctx.get().getSender();
            if (sender != null) {
                ServerLevel level = sender.serverLevel();
                boolean enabled = TycoonStats.get(level).isTycoonEnabled(msg.traderId);
                TycoonNetwork.CHANNEL.send(
                        PacketDistributor.PLAYER.with(() -> sender),
                        new S2CSyncTycoonStatusPacket(msg.traderId, enabled)
                );
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
