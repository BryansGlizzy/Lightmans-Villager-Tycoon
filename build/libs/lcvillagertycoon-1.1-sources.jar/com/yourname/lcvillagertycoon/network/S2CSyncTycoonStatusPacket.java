package com.yourname.lcvillagertycoon.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import com.yourname.lcvillagertycoon.client.TycoonScreenEvents;

import java.util.function.Supplier;

public class S2CSyncTycoonStatusPacket {
    private final long traderId;
    private final boolean enabled;

    public S2CSyncTycoonStatusPacket(long traderId, boolean enabled) {
        this.traderId = traderId;
        this.enabled = enabled;
    }

    public static void encode(S2CSyncTycoonStatusPacket msg, FriendlyByteBuf buf) {
        buf.writeLong(msg.traderId);
        buf.writeBoolean(msg.enabled);
    }

    public static S2CSyncTycoonStatusPacket decode(FriendlyByteBuf buf) {
        return new S2CSyncTycoonStatusPacket(buf.readLong(), buf.readBoolean());
    }

    public static void handle(S2CSyncTycoonStatusPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            TycoonScreenEvents.updateTycoonStatus(msg.traderId, msg.enabled);
        });
        ctx.get().setPacketHandled(true);
    }
}
