package com.yourname.lcvillagertycoon.client;

import com.yourname.lcvillagertycoon.network.C2SRequestTycoonStatusPacket;
import com.yourname.lcvillagertycoon.network.C2SToggleTycoonPacket;
import com.yourname.lcvillagertycoon.network.TycoonNetwork;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = "lcvillagertycoon", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class TycoonScreenEvents {

    private static final Map<Long, Boolean> clientTycoonStatus = new HashMap<>();
    private static long currentTraderId = -1;
    private static Button tycoonToggleButton = null;

    public static void updateTycoonStatus(long traderId, boolean enabled) {
        clientTycoonStatus.put(traderId, enabled);
        if (currentTraderId == traderId && tycoonToggleButton != null) {
            updateButtonText();
        }
    }

    private static void updateButtonText() {
        if (tycoonToggleButton != null) {
            boolean enabled = clientTycoonStatus.getOrDefault(currentTraderId, true);
            tycoonToggleButton.setMessage(Component.literal("Tycoon: " + (enabled ? "ON" : "OFF")));
        }
    }

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        Screen screen = event.getScreen();
        // Check if it's the LC TraderStorageScreen (Owner/Settings view)
        if (screen.getClass().getName().contains("io.github.lightman314.lightmanscurrency") && screen.getClass().getName().endsWith("TraderStorageScreen")) {
            currentTraderId = extractTraderId(screen);
            
            if (currentTraderId != -1) {
                // Request current status from server
                TycoonNetwork.CHANNEL.sendToServer(new C2SRequestTycoonStatusPacket(currentTraderId));
                
                // Add toggle button near the top center
                int btnWidth = 80;
                int btnHeight = 20;
                int x = screen.width / 2 - btnWidth / 2;
                int y = 5;

                boolean initialStatus = clientTycoonStatus.getOrDefault(currentTraderId, true);
                
                tycoonToggleButton = Button.builder(Component.literal("Tycoon: " + (initialStatus ? "ON" : "OFF")), btn -> {
                    boolean current = clientTycoonStatus.getOrDefault(currentTraderId, true);
                    boolean newState = !current;
                    clientTycoonStatus.put(currentTraderId, newState);
                    updateButtonText();
                    TycoonNetwork.CHANNEL.sendToServer(new C2SToggleTycoonPacket(currentTraderId, newState));
                }).bounds(x, y, btnWidth, btnHeight).build();

                tycoonToggleButton.visible = false; // Hidden by default, only shown on Trade Rules tab
                event.addListener(tycoonToggleButton);
            }
        }
    }

    private static long extractTraderId(Screen screen) {
        try {
            if (screen instanceof net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?> containerScreen) {
                Object menu = containerScreen.getMenu();
                java.lang.reflect.Method getTraderMethod = menu.getClass().getMethod("getTrader");
                Object traderData = getTraderMethod.invoke(menu);
                if (traderData != null) {
                    java.lang.reflect.Method getIdMethod = traderData.getClass().getMethod("getID");
                    return (long) getIdMethod.invoke(traderData);
                }
            }
        } catch (Exception e) {
            // Ignore if method not found / not the right menu
        }
        return -1;
    }

    @SubscribeEvent
    public static void onScreenRender(ScreenEvent.Render.Post event) {
        Screen screen = event.getScreen();
        if (screen.getClass().getName().contains("io.github.lightman314.lightmanscurrency") && screen.getClass().getName().endsWith("TraderStorageScreen")) {
            if (tycoonToggleButton != null) {
                boolean isTradeRulesTab = false;
                try {
                    // Use reflection to call the protected getCurrentTab() method
                    java.lang.reflect.Method getTabMethod = null;
                    Class<?> clazz = screen.getClass();
                    while (clazz != Object.class) {
                        try {
                            getTabMethod = clazz.getDeclaredMethod("getCurrentTab");
                            break;
                        } catch (NoSuchMethodException ex) {
                            clazz = clazz.getSuperclass();
                        }
                    }
                    if (getTabMethod != null) {
                        getTabMethod.setAccessible(true);
                        Object tabObj = getTabMethod.invoke(screen);
                        if (tabObj != null && tabObj.getClass().getName().contains("TradeRules")) {
                            isTradeRulesTab = true;
                        }
                    }
                } catch (Exception e) {
                    // Ignore reflection errors silently in render loop
                }
                
                tycoonToggleButton.visible = isTradeRulesTab;
                
                // Keep its position glued to the top right of the GUI bounds if possible
                if (screen instanceof net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?> containerScreen) {
                    int guiLeft = containerScreen.getGuiLeft();
                    int guiTop = containerScreen.getGuiTop();
                    tycoonToggleButton.setX(guiLeft + 120); // Adjust X to fit nicely in the tab
                    tycoonToggleButton.setY(guiTop + 5);
                }
            }
        }
    }
}
